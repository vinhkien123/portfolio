
import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import Particles from 'react-tsparticles';
import Loading from './Component/Loadding';
import './Component/Loadding/style.scss'
function App() {
  const [flag, setFlag] = useState(true)
  useEffect(() => {
    setTimeout(() => {
      setFlag(false)
    }, 4000)
  }, [])
  return (
    <div className="App">
      <section className='loading'>
        <Loading />
        {/* {flag ?
          <Particles
            id="tsparticles"

            options={{
              fpsLimit: 60,
              interactivity: {
                detectsOn: "canvas",
                events: {
                  onClick: {
                    enable: true,
                    mode: "push",
                  },
                  onHover: {
                    enable: true,
                    mode: "repulse",
                  },
                  resize: true,
                },
                modes: {
                  bubble: {
                    distance: 400,
                    duration: 2,
                    opacity: 0.8,
                    size: 40,
                  },
                  push: {
                    quantity: 4,
                  },
                  repulse: {
                    distance: 200,
                    duration: 0.4,
                  },
                },
              },
              particles: {
                color: {
                  value: "#000000",
                },
                links: {
                  color: "#000000",
                  distance: 150,
                  enable: true,
                  opacity: 0.5,
                  width: 1,
                },
                collisions: {
                  enable: true,
                },
                move: {
                  direction: "none",
                  enable: true,
                  outMode: "bounce",
                  random: false,
                  speed: 4,
                  straight: false,
                },
                number: {
                  density: {
                    enable: true,
                    value_area: 800,
                  },
                  value: 80,
                },

                opacity: {
                  value: 0.5,
                },
                shape: {
                  type: "circle",
                },
                size: {
                  random: true,
                  value: 5,
                },
              },
              detectRetina: true,
            }}
          /> : <></>
        } */}
      </section>
      <section class="section">
        <h1>Change / Modify</h1>

        <h2>Three.js Objects</h2>
        <h1>On scroll</h1>
      </section>
      <section class="section">
        <h1>Rotate - Them</h1>
      </section>
      <section class="section">
        <h1>Scale - Them</h1>
      </section>
      <section class="section">
        <h1>Do Whatever you want with them</h1>
        <h2>Three.js Tutorial</h2>
        <h1>GSAP + Scrolltrigger</h1>
      </section>

    </div>
  );
}

export default App;
